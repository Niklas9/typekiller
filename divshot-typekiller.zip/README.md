Typekiller
==========

A web browser client game to compete in typewriting.
Written in JavaScript with help of the nifty Angular.js framework.

Still in its infancy.